#ifndef FIGHTER_NO_SYCL
#include <sycl/sycl.hpp>
#endif
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <immintrin.h>
#include <iostream>
#include <thread>
#include <vector>

#include "fighter_active_head.hpp"
#include "fighter_lsh.hpp"
#include "fighter_radar_sycl.hpp"
#include "fighter_types.hpp"

#ifdef FIGHTER_NO_SYCL
using SysQueue = int;
using SysEvent = MockEvent;
#else
using SysQueue = sycl::queue;
using SysEvent = sycl::event;
#endif

static inline void prefetch_t0(const void *p) {
  _mm_prefetch((const char *)p, _MM_HINT_T0);
}

static inline void cell_shift_inject(float *state8, const float *payload8,
                                     int16_t mix_q14) {
  const __m256 v_mix = _mm256_set1_ps(float(mix_q14) * (1.0f / 16384.0f));
  __m256 v_s = _mm256_load_ps(state8);
  __m256 v_p = _mm256_load_ps(payload8);
  _mm256_store_ps(state8, _mm256_fmadd_ps(v_p, v_mix, v_s));
}

// Minimalus „state evolution“ (vietoje tavo full kernelio).
// Čia tik branchless FMA + permute idėjai. Integruosi savo fast_kernel_v7
// viduje.
static inline void evolve_state16(float *st16, uint32_t perm_idx, float beta) {
  static const uint32_t PERM_TABLE[4][8] = {{0, 1, 2, 3, 4, 5, 6, 7},
                                            {4, 5, 6, 7, 0, 1, 2, 3},
                                            {0, 2, 4, 6, 1, 3, 5, 7},
                                            {7, 6, 5, 4, 3, 2, 1, 0}};
  __m256i ctrl = _mm256_loadu_si256((const __m256i *)PERM_TABLE[perm_idx & 3]);

  __m256 a0 = _mm256_load_ps(st16 + 0);
  __m256 a1 = _mm256_load_ps(st16 + 8);

  a0 = _mm256_permutevar8x32_ps(a0, ctrl);
  a1 = _mm256_permutevar8x32_ps(a1, ctrl);

  // beta įtaka: st = st + beta*(shifted - st)
  __m256 vb = _mm256_set1_ps(beta);
  __m256 d0 = _mm256_sub_ps(a0, _mm256_load_ps(st16 + 0));
  __m256 d1 = _mm256_sub_ps(a1, _mm256_load_ps(st16 + 8));
  _mm256_store_ps(st16 + 0, _mm256_fmadd_ps(vb, d0, _mm256_load_ps(st16 + 0)));
  _mm256_store_ps(st16 + 8, _mm256_fmadd_ps(vb, d1, _mm256_load_ps(st16 + 8)));
}

static inline void top1_from_scores(const uint16_t *scores, size_t n,
                                    uint32_t &best_idx, uint16_t &best_score) {
  best_idx = 0;
  best_score = 0xFFFF;
  // Unroll 4
  for (size_t i = 0; i < n; i += 4) {
    uint16_t s0 = scores[i + 0];
    uint16_t s1 = (i + 1 < n) ? scores[i + 1] : 0xFFFF;
    uint16_t s2 = (i + 2 < n) ? scores[i + 2] : 0xFFFF;
    uint16_t s3 = (i + 3 < n) ? scores[i + 3] : 0xFFFF;
    if (s0 < best_score) {
      best_score = s0;
      best_idx = (uint32_t)(i + 0);
    }
    if (s1 < best_score) {
      best_score = s1;
      best_idx = (uint32_t)(i + 1);
    }
    if (s2 < best_score) {
      best_score = s2;
      best_idx = (uint32_t)(i + 2);
    }
    if (s3 < best_score) {
      best_score = s3;
      best_idx = (uint32_t)(i + 3);
    }
  }
}

static inline int16_t q8_from_hamming(uint16_t dist) {
  // dist 0..128 -> score 127..-1 (clamp)
  int v = 127 - (int)dist;
  if (v < -127)
    v = -127;
  if (v > 127)
    v = 127;
  return (int16_t)v;
}

struct Config {
  uint64_t steps = 20000;
  uint32_t refresh_mask = 0xFFFF;
  uint32_t chunks = 4096;
  uint32_t vocab = 32768;

  // ActiveHead CAP (power of two) – i3 L3=12MB: 131072 arba 262144.
  uint32_t head_cap = 131072;

  // GA/Backpressure
  uint16_t radar_threshold = 40; // hamming <= threshold -> inject
  int16_t mix_base_q14 = 4096;   // 0.25
  int16_t mix_gain_q14 = 64;     // papildomas per (threshold-dist)
};

static void worker_thread(std::atomic<bool> &stop, const Config &cfg,
                          ResonanceBridge *bridge, StateSketch *shared_sig,
                          const LSHProjTable *lsh, const float *payloads,
                          std::atomic<uint64_t> &tokens_done,
                          std::atomic<uint64_t> &injections_done) {
  alignas(32) float state16[16];
  for (int i = 0; i < 16; ++i)
    state16[i] = 0.01f * (float)(i + 1);

  uint32_t sig4[4]{0, 0, 0, 0};
  StepCommand cmd{};
  uint32_t perm_idx = 0;
  float beta = 0.12f;
  uint32_t rng = 0xA123BEEF;

  auto t0 = std::chrono::high_resolution_clock::now();

  for (uint64_t i = 0; i < cfg.steps && !stop.load(std::memory_order_relaxed);
       ++i) {
    // Micro-GA stub: keičiam perm_idx/beta labai pigiai (vietoje tavo pilno).
    if ((i & 0x3FFF) == 0) {
      perm_idx = (perm_idx + 1) & 3;
      beta = 0.08f + 0.08f * float(xorshift32(rng) & 0xFF) / 255.0f;
    }

    evolve_state16(state16, perm_idx, beta);

    if (((uint32_t)i & cfg.refresh_mask) == 0u) {
      make_state_sig_lsh128(state16, *lsh, sig4);
      write_state_sig(*shared_sig, sig4);

      if (bridge->pop(cmd)) {
        const float *p = payloads + (size_t)cmd.inject_idx * 8;
        int off = (cmd.target_slot ? 8 : 0);
        cell_shift_inject(state16 + off, p, cmd.mix_q14);
        injections_done.fetch_add(1, std::memory_order_relaxed);
      }
    }

    // Token emit čia minimalus (tik skaitiklis). Real token stream bus per
    // cmd.token_id.
    tokens_done.fetch_add(1, std::memory_order_relaxed);
  }

  auto t1 = std::chrono::high_resolution_clock::now();
  double sec = std::chrono::duration<double>(t1 - t0).count();
  if (sec > 0.0) {
    double tps = double(tokens_done.load()) / sec;
    std::cout << "Worker TPS: " << (uint64_t)tps << "\n";
  }
  stop.store(true, std::memory_order_relaxed);
}

template <int TOPK, uint32_t CAP>
static void manager_thread(std::atomic<bool> &stop, const Config &cfg,
                           ResonanceBridge *bridge,
                           const StateSketch *shared_sig, SysQueue &q,
                           const ChunkSketch *archive, uint16_t *scores,
                           const float *payloads, ActiveHead<TOPK, CAP> &head,
                           std::atomic<uint64_t> &scans_done,
                           std::atomic<uint64_t> &pushes_done,
                           std::atomic<uint64_t> &bridge_overflows) {
  uint32_t sig4[4]{0, 0, 0, 0};
  uint16_t global_age = 1;
  uint32_t rng = 0xC001D00D;

  // Pipeline: visada laikom "previous scan event"
  bool have_event = false;
  SysEvent ev;

  // GA knobs
  uint16_t threshold = cfg.radar_threshold;
  int16_t mix_base = cfg.mix_base_q14;
  int16_t mix_gain = cfg.mix_gain_q14;

  while (!stop.load(std::memory_order_relaxed)) {
    read_state_sig(*shared_sig, sig4);

    // Submit radar scan (async). Manager gali laukti ankstesnio rezultato –
    // Worker nestovi.
    ev = scan_radar(q, sig4, archive, scores, cfg.chunks);
    scans_done.fetch_add(1, std::memory_order_relaxed);
    have_event = true;

    // Wait scan completion (Manager thread, atskira nuo Worker)
    ev.wait();

    // Pick best chunk (Top1)
    uint32_t best_idx = 0;
    uint16_t best_dist = 0xFFFF;
    top1_from_scores(scores, cfg.chunks, best_idx, best_dist);

    // Prefetch payload, kad Worker'ui injekcija būtų cache-friendly
    const float *pay = payloads + (size_t)best_idx * 8;
    prefetch_t0(pay);

    // Token selection:
    // 1) ActiveHead lookup
    uint32_t tok = 0;
    int16_t tq8 = (int16_t)-32768;
    bool ok = head.lookup_best(sig4, tok, tq8);

    // 2) Jei nėra – fallback iš "rezonanso" (pseudo-token) + reinforcement
    if (!ok) {
      tok = (best_idx % cfg.vocab);
      tq8 = q8_from_hamming(best_dist);
    }

    // Reinforce (online). Jei turėsi teacher, čia įdėsi teacher tok/q8.
    head.reinforce(sig4, tok, tq8, global_age);
    global_age++;

    // Injection decision + GA/backpressure
    StepCommand cmd{};
    cmd.inject_idx = best_idx;
    cmd.score = best_dist;

    // target_slot: kuo mažesnis dist, tuo labiau "long-term"
    cmd.target_slot = (best_dist < (threshold / 2)) ? 1 : 0;

    // mix: base + gain*(threshold - dist), clamp
    int d = int(threshold) - int(best_dist);
    if (d < 0)
      d = 0;
    int mix = int(mix_base) + d * int(mix_gain);
    if (mix > 16384)
      mix = 16384;
    if (mix < 0)
      mix = 0;
    cmd.mix_q14 = (int16_t)mix;

    cmd.token_id = tok;
    cmd.flags = 0;

    if (!bridge->push(cmd)) {
      bridge_overflows.fetch_add(1, std::memory_order_relaxed);
      // Meta-GA: jei overflow, švelninam injekcijas (mažinam mix/threshold)
      if (threshold > 8)
        threshold -= 1;
      if (mix_base > 512)
        mix_base -= 128;
    } else {
      pushes_done.fetch_add(1, std::memory_order_relaxed);
      // Jei injekcijos eina be overflows – galima didinti agresiją
      if ((pushes_done.load(std::memory_order_relaxed) & 0x3FF) == 0) {
        if (threshold < 64)
          threshold += 1;
      }
    }

    // Manager pacing: minimalus sleep, kad neužsmaugtų OS schedulerio
    std::this_thread::sleep_for(std::chrono::microseconds(50));
  }
}

int main(int argc, char **argv) {
  Config cfg;
  for (int i = 1; i < argc; i++) {
    if (!std::strcmp(argv[i], "--steps") && i + 1 < argc)
      cfg.steps = std::strtoull(argv[++i], nullptr, 10);
    else if (!std::strcmp(argv[i], "--chunks") && i + 1 < argc)
      cfg.chunks = (uint32_t)std::strtoul(argv[++i], nullptr, 10);
    else if (!std::strcmp(argv[i], "--refresh") && i + 1 < argc)
      cfg.refresh_mask = (uint32_t)std::strtoul(argv[++i], nullptr, 0);
    else if (!std::strcmp(argv[i], "--vocab") && i + 1 < argc)
      cfg.vocab = (uint32_t)std::strtoul(argv[++i], nullptr, 10);
    else if (!std::strcmp(argv[i], "--head") && i + 1 < argc)
      cfg.head_cap = (uint32_t)std::strtoul(argv[++i], nullptr, 10);
  }

  std::cout << "Fighter V3\n";
  std::cout << "  steps=" << cfg.steps << " chunks=" << cfg.chunks
            << " refresh_mask=0x" << std::hex << cfg.refresh_mask << std::dec
            << " vocab=" << cfg.vocab << " head_cap=" << cfg.head_cap << "\n";

  // SYCL queue selection: prefer GPU, fallback to default.
  // SYCL queue selection: prefer GPU, fallback to default.
#ifndef FIGHTER_NO_SYCL
  sycl::queue q;
  try {
    q = sycl::queue(sycl::gpu_selector_v);
  } catch (...) {
    q = sycl::queue(sycl::default_selector_v);
  }
  std::cout << "SYCL device: "
            << q.get_device().get_info<sycl::info::device::name>() << "\n";

  // USM allocations (shared): archive + scores + payloads
  ChunkSketch *archive = sycl::malloc_shared<ChunkSketch>(cfg.chunks, q);
  uint16_t *scores = sycl::malloc_shared<uint16_t>(cfg.chunks, q);
  float *payloads = sycl::malloc_shared<float>(cfg.chunks * 8, q);

  if (!archive || !scores || !payloads) {
    std::cerr << "USM allocation failed\n";
    return 1;
  }
#else
  SysQueue q = 0;
  std::cout << "Running in CPU-only (Pure Metal) mode via -DFIGHTER_NO_SYCL\n";

  // Allocations using _mm_malloc (64-byte aligned for AVX)
  ChunkSketch *archive =
      (ChunkSketch *)_mm_malloc(sizeof(ChunkSketch) * cfg.chunks, 64);
  uint16_t *scores = (uint16_t *)_mm_malloc(sizeof(uint16_t) * cfg.chunks, 64);
  float *payloads = (float *)_mm_malloc(sizeof(float) * cfg.chunks * 8, 64);

  if (!archive || !scores || !payloads) {
    std::cerr << "CPU allocation failed\n";
    return 1;
  }

  // Explicitly zero-init scores for safety
  std::memset(scores, 0xFF, sizeof(uint16_t) * cfg.chunks);
#endif

  // Init archive + payloads (MVP synthetic). TeacherAlign vėliau pakeis tai
  // realiais duomenimis.
  uint32_t rng = 0x12345678;
  for (uint32_t i = 0; i < cfg.chunks; ++i) {
    archive[i].chunk_idx = i;
    for (int k = 0; k < 4; ++k)
      archive[i].sign_bits[k] = xorshift32(rng);
    for (int lane = 0; lane < 8; ++lane)
      payloads[i * 8 + lane] =
          0.001f * float((int)(xorshift32(rng) & 1023) - 512);
    scores[i] = 0xFFFF;
  }

  // LSH seeds + table
  alignas(64) uint32_t seeds[256];
  for (int i = 0; i < 256; ++i)
    seeds[i] = xorshift32(rng);
  LSHProjTable lsh{};
  build_lsh_table(lsh, seeds);

  // Shared state signature & bridge
  StateSketch shared_sig;
  ResonanceBridge bridge;

  // ActiveHead backing storage
  static constexpr int TOPK = 4;
  // head_cap must be power-of-two and compile-time for template; provide common
  // caps:
  if (cfg.head_cap != 131072 && cfg.head_cap != 262144) {
    std::cerr << "head_cap must be 131072 or 262144 in this build\n";
    return 2;
  }

  std::atomic<bool> stop{false};
  std::atomic<uint64_t> tokens_done{0}, injections_done{0};
  std::atomic<uint64_t> scans_done{0}, pushes_done{0}, bridge_overflows{0};

  auto t0 = std::chrono::high_resolution_clock::now();

  if (cfg.head_cap == 131072) {
    static HeadEntry<TOPK> head_mem[131072];
    ActiveHead<TOPK, 131072> head;
    head.init(head_mem);

    std::thread w(worker_thread, std::ref(stop), std::cref(cfg), &bridge,
                  &shared_sig, &lsh, payloads, std::ref(tokens_done),
                  std::ref(injections_done));
    std::thread m(manager_thread<TOPK, 131072>, std::ref(stop), std::cref(cfg),
                  &bridge, &shared_sig, std::ref(q), archive, scores, payloads,
                  std::ref(head), std::ref(scans_done), std::ref(pushes_done),
                  std::ref(bridge_overflows));
    w.join();
    m.join();
  } else {
    static HeadEntry<TOPK> head_mem[262144];
    ActiveHead<TOPK, 262144> head;
    head.init(head_mem);

    std::thread w(worker_thread, std::ref(stop), std::cref(cfg), &bridge,
                  &shared_sig, &lsh, payloads, std::ref(tokens_done),
                  std::ref(injections_done));
    std::thread m(manager_thread<TOPK, 262144>, std::ref(stop), std::cref(cfg),
                  &bridge, &shared_sig, std::ref(q), archive, scores, payloads,
                  std::ref(head), std::ref(scans_done), std::ref(pushes_done),
                  std::ref(bridge_overflows));
    w.join();
    m.join();
  }

  auto t1 = std::chrono::high_resolution_clock::now();
  double sec = std::chrono::duration<double>(t1 - t0).count();

  std::cout << "Results:\n";
  std::cout << "  Wall: " << sec << " s\n";
  std::cout << "  Tokens: " << tokens_done.load() << "\n";
  std::cout << "  Scans: " << scans_done.load() << "\n";
  std::cout << "  Manager pushes: " << pushes_done.load() << "\n";
  std::cout << "  Injections: " << injections_done.load() << "\n";
  std::cout << "  Bridge overflows: " << bridge_overflows.load() << "\n";

#ifndef FIGHTER_NO_SYCL
  sycl::free(archive, q);
  sycl::free(scores, q);
  sycl::free(payloads, q);
#else
  _mm_free(archive);
  _mm_free(scores);
  _mm_free(payloads);
#endif
  return 0;
}

#pragma once
#include <immintrin.h>
#include <cstdint>
#include "fighter_types.hpp"

// LSH projection table: 16 groups, each group produces 8 bits (movemask of 8 lanes) => 128 bits.
struct alignas(32) LSHProjTable {
    __m256 sign[16][16]; // [group][dim] -> 8 lane signs
};

// Build table from seeds. Seeds must have 16*16 entries.
static inline void build_lsh_table(LSHProjTable& tab, const uint32_t* seeds256) {
    for (int g = 0; g < 16; ++g) {
        for (int d = 0; d < 16; ++d) {
            uint32_t s = seeds256[g * 16 + d];
            alignas(32) float tmp[8];
            for (int lane = 0; lane < 8; ++lane) {
                tmp[lane] = (xorshift32(s) & 1u) ? 1.0f : -1.0f;
            }
            tab.sign[g][d] = _mm256_load_ps(tmp);
        }
    }
}

// state16 -> 128-bit signature (4x uint32)
static inline void make_state_sig_lsh128(const float* state16, const LSHProjTable& tab, uint32_t out_sig[4]) {
    out_sig[0]=out_sig[1]=out_sig[2]=out_sig[3]=0u;
    for (int g = 0; g < 16; ++g) {
        __m256 acc = _mm256_setzero_ps();
        for (int d = 0; d < 16; ++d) {
            acc = _mm256_fmadd_ps(_mm256_set1_ps(state16[d]), tab.sign[g][d], acc);
        }
        uint32_t bits8 = (uint32_t)_mm256_movemask_ps(acc); // 8 bits
        out_sig[g >> 2] |= (bits8 << ((g & 3) << 3));
    }
}

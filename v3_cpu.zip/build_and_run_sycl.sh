#!/usr/bin/env bash
set -euo pipefail

# Optional: force GPU (Level Zero). If no GPU driver, it will fail and you can remove it.
export SYCL_DEVICE_FILTER=level_zero:gpu

icpx -O3 -DNDEBUG -std=c++20 -mavx2 -mfma -fsycl fighter_v3.cpp -o fighter_v3
./fighter_v3 --steps 200000 --chunks 4096 --head 131072

#pragma once
#include "fighter_types.hpp"

#ifdef FIGHTER_NO_SYCL
#include <cstdint>
#include <cstdlib>
#if defined(_MSC_VER)
#include <intrin.h>
#else
#include <x86intrin.h>
#endif

// Mock types to satisfy the function signature
struct MockEvent {
    void wait() {}
};

// CPU implementation (Pure Metal)
// Using pure scalar loop with hardware POPCNT.
// Compiler with -O3 -mavx2 should struggle to vectorize popcnt unless using AVX512_VPOPCNTDQ.
// But basic POPCNT is fast enough for baseline.
static inline MockEvent scan_radar(int /*ignored_q*/,
                                   const uint32_t* state_sig4,
                                   const ChunkSketch* archive,
                                   uint16_t* scores,
                                   size_t n_chunks) {
    for (size_t i = 0; i < n_chunks; ++i) {
        uint32_t dist = 0;
        uint32_t x0 = state_sig4[0] ^ archive[i].sign_bits[0];
        uint32_t x1 = state_sig4[1] ^ archive[i].sign_bits[1];
        uint32_t x2 = state_sig4[2] ^ archive[i].sign_bits[2];
        uint32_t x3 = state_sig4[3] ^ archive[i].sign_bits[3];

#if defined(_MSC_VER)
        dist += __popcnt(x0);
        dist += __popcnt(x1);
        dist += __popcnt(x2);
        dist += __popcnt(x3);
#else
        dist += _mm_popcnt_u32(x0);
        dist += _mm_popcnt_u32(x1);
        dist += _mm_popcnt_u32(x2);
        dist += _mm_popcnt_u32(x3);
#endif
        scores[i] = (uint16_t)dist;
    }
    return MockEvent{};
}

#else
#include <sycl/sycl.hpp>

// iGPU radar: XOR + popcount => uint16 score (lower better).
static inline sycl::event scan_radar(sycl::queue& q,
                                    const uint32_t* state_sig4,
                                    const ChunkSketch* archive,
                                    uint16_t* scores,
                                    size_t n_chunks) {
    return q.submit([&](sycl::handler& h) {
        h.parallel_for(sycl::range<1>(n_chunks), [=](sycl::id<1> id) {
            size_t i = id[0];
            uint32_t dist = 0;
            #pragma unroll
            for (int k=0;k<4;++k) dist += sycl::popcount(state_sig4[k] ^ archive[i].sign_bits[k]);
            scores[i] = (uint16_t)dist;
        });
    });
}
#endif

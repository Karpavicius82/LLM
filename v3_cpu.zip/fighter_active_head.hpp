#pragma once
#include <cstdint>
#include <cstring>

static inline uint64_t mix64(uint64_t x) {
    x ^= x >> 33;
    x *= 0xff51afd7ed558ccdULL;
    x ^= x >> 33;
    x *= 0xc4ceb9fe1a85ec53ULL;
    x ^= x >> 33;
    return x;
}

static inline uint64_t key64_from_sig128(const uint32_t sig[4]) {
    uint64_t a = (uint64_t(sig[0]) << 32) | sig[1];
    uint64_t b = (uint64_t(sig[2]) << 32) | sig[3];
    return mix64(a ^ mix64(b));
}

template<int TOPK>
struct alignas(32) HeadEntry {
    uint64_t key;      // 0 = empty
    uint16_t age;
    uint16_t seen;
    uint32_t tok[TOPK];
    int16_t  q8[TOPK];
    uint16_t pad;
};

template<int TOPK>
static inline void head_entry_init(HeadEntry<TOPK>& e) {
    e.key=0; e.age=0; e.seen=0; e.pad=0;
    for (int i=0;i<TOPK;++i) { e.tok[i]=0; e.q8[i]=(int16_t)-32768; }
}

template<int TOPK>
static inline void head_try_insert(HeadEntry<TOPK>& e, uint32_t tok, int16_t q8) {
    for (int i=0;i<TOPK;++i) {
        if (e.tok[i] == tok) { if (q8 > e.q8[i]) e.q8[i] = q8; return; }
    }
    int worst = 0;
    for (int i=1;i<TOPK;++i) if (e.q8[i] < e.q8[worst]) worst = i;
    if (q8 <= e.q8[worst]) return;
    e.tok[worst]=tok; e.q8[worst]=q8;

    for (int i=0;i<TOPK-1;++i) for (int j=i+1;j<TOPK;++j) {
        if (e.q8[j] > e.q8[i]) {
            int16_t tq=e.q8[i]; e.q8[i]=e.q8[j]; e.q8[j]=tq;
            uint32_t tt=e.tok[i]; e.tok[i]=e.tok[j]; e.tok[j]=tt;
        }
    }
}

template<int TOPK, uint32_t CAP_POW2>
class ActiveHead {
public:
    static constexpr uint32_t CAP  = CAP_POW2;
    static constexpr uint32_t MASK = CAP_POW2 - 1u;

    HeadEntry<TOPK>* table = nullptr;

    void init(HeadEntry<TOPK>* backing) {
        table = backing;
        for (uint32_t i=0;i<CAP;++i) head_entry_init(table[i]);
    }

    bool lookup_best(const uint32_t sig[4], uint32_t& out_tok, int16_t& out_q8) const {
        uint64_t key = key64_from_sig128(sig);
        uint32_t idx = (uint32_t)key & MASK;

        for (uint32_t probe=0; probe<64; ++probe) {
            const auto& e = table[(idx + probe) & MASK];
            if (e.key == 0) return false;
            if (e.key == key) {
                out_tok = e.tok[0];
                out_q8  = e.q8[0];
                return (out_q8 > (int16_t)-32000);
            }
        }
        return false;
    }

    void reinforce(const uint32_t sig[4], uint32_t tok, int16_t q8, uint16_t global_age) {
        uint64_t key = key64_from_sig128(sig);
        uint32_t idx = (uint32_t)key & MASK;

        int32_t first_free = -1;
        uint32_t best_evict = 0;
        uint32_t best_score = 0xFFFFFFFFu;

        for (uint32_t probe=0; probe<128; ++probe) {
            uint32_t p = (idx + probe) & MASK;
            auto& e = table[p];

            if (e.key == 0) { first_free = (int32_t)p; break; }
            if (e.key == key) {
                head_try_insert(e, tok, q8);
                e.seen = (e.seen < 0xFFFF) ? (uint16_t)(e.seen + 1) : e.seen;
                e.age  = global_age;
                return;
            }

            uint32_t age_delta = uint32_t(global_age - e.age);
            uint32_t score = (age_delta << 16) | uint32_t(0xFFFFu - e.seen);
            if (score < best_score) { best_score = score; best_evict = p; }
        }

        uint32_t put = (first_free >= 0) ? (uint32_t)first_free : best_evict;
        auto& e = table[put];
        e.key = key;
        e.age = global_age;
        e.seen = 1;
        for (int i=0;i<TOPK;++i) { e.tok[i]=0; e.q8[i]=(int16_t)-32768; }
        head_try_insert(e, tok, q8);
    }
};

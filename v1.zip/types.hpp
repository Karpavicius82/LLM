// types.hpp
#pragma once
#include <atomic>
#include <cstdint>
#include <cstring>

#if defined(_MSC_VER)
  #include <intrin.h>
#endif

// 32B: 4*4 + 4 + 12 = 32
struct alignas(32) ChunkSketch {
    uint32_t sign_bits[4]; // 128-bit signature
    uint32_t chunk_idx;    // 0..N-1 (adresavimui)
    uint32_t reserved[3];
};

struct InjectCommand {
    uint32_t chunk_idx;    // payload indeksas
    uint16_t score;        // mažiau = geriau
    uint16_t target_slot;  // 0=short(off0), 1=long(off8)
};

// SPSC Manager->Worker. Kritiška: head ir tail turi būti skirtingose cache line.
struct ResonanceBridge {
    alignas(64) std::atomic<uint64_t> head{0};
    uint8_t pad0[64 - sizeof(std::atomic<uint64_t>)];

    alignas(64) std::atomic<uint64_t> tail{0};
    uint8_t pad1[64 - sizeof(std::atomic<uint64_t>)];

    alignas(64) InjectCommand queue[16];

    bool push(const InjectCommand& cmd) {
        const uint64_t t = tail.load(std::memory_order_relaxed);
        const uint64_t h = head.load(std::memory_order_acquire);
        if (t - h >= 16) return false;
        queue[t & 15] = cmd;
        tail.store(t + 1, std::memory_order_release);
        return true;
    }

    bool pop(InjectCommand& cmd) {
        const uint64_t h = head.load(std::memory_order_relaxed);
        const uint64_t t = tail.load(std::memory_order_acquire);
        if (h == t) return false;
        cmd = queue[h & 15];
        head.store(h + 1, std::memory_order_release);
        return true;
    }
};

// Seq-lock shared signature (worker rašo, manager skaito)
struct alignas(64) StateSketch {
    std::atomic<uint32_t> seq{0}; // even=stable, odd=writing
    uint32_t sig[4]{0,0,0,0};
};

static inline void write_state_sig(StateSketch& ss, const uint32_t sig4[4]) {
    uint32_t s = ss.seq.load(std::memory_order_relaxed);
    ss.seq.store(s + 1, std::memory_order_release); // odd -> writing
    ss.sig[0] = sig4[0];
    ss.sig[1] = sig4[1];
    ss.sig[2] = sig4[2];
    ss.sig[3] = sig4[3];
    ss.seq.store(s + 2, std::memory_order_release); // even -> stable
}

static inline void read_state_sig(StateSketch& ss, uint32_t out_sig4[4]) {
    for (;;) {
        uint32_t a = ss.seq.load(std::memory_order_acquire);
        if (a & 1u) continue; // writing
        out_sig4[0] = ss.sig[0];
        out_sig4[1] = ss.sig[1];
        out_sig4[2] = ss.sig[2];
        out_sig4[3] = ss.sig[3];
        uint32_t b = ss.seq.load(std::memory_order_acquire);
        if (a == b) return;
    }
}

// counters
struct Counters {
    std::atomic<uint64_t> scans{0};
    std::atomic<uint64_t> inject_applied{0};
    std::atomic<uint64_t> inject_dropped{0};
    std::atomic<uint64_t> bridge_full{0};
};

// engine_main.cpp
#include <chrono>
#include <cstring>
#include <immintrin.h>
#include <iostream>
#include <thread>
#include <vector>


#include "lsh_signer.hpp"
#include "types.hpp"


#ifndef FIGHTER_NO_SYCL
#include <sycl/sycl.hpp>
sycl::event scan_resonance(sycl::queue &q, const uint32_t *state_sig,
                           const ChunkSketch *archive, uint16_t *scores,
                           size_t num_chunks);
#endif

// ---------- config ----------
static constexpr uint32_t REFRESH_MASK = 0xFFFF;
static constexpr int MIX_BANK_SIZE = 2048;
static constexpr int SEED_COUNT = 256;

// chunk payload: 8 float = 32B (aligned), injekcijai
static inline const float *payload_ptr(const float *payloads,
                                       uint32_t chunk_idx) {
  return payloads + (size_t)chunk_idx * 8;
}

static inline void prefetch_payload(const float *p) {
  _mm_prefetch((const char *)p, _MM_HINT_T0);
}

// Q1.14 injekcija: state8 += payload8 * mix
static inline void apply_injection(float *state8, const float *payload8,
                                   int16_t mix_q14) {
  const __m256 v_mix = _mm256_set1_ps(float(mix_q14) * (1.0f / 16384.0f));
  __m256 v_state = _mm256_load_ps(state8);
  __m256 v_payload = _mm256_load_ps(payload8);
  __m256 v_new = _mm256_fmadd_ps(v_payload, v_mix, v_state);
  _mm256_store_ps(state8, v_new);
}

// minimalus "kernel" stub: pakeisi savo fast_kernel_v7
static inline void fast_kernel_stub(float state16[16]) {
  // pigu, branchless
  __m256 a = _mm256_load_ps(state16);
  __m256 b = _mm256_load_ps(state16 + 8);
  a = _mm256_fmadd_ps(a, _mm256_set1_ps(1.00001f), _mm256_set1_ps(0.00001f));
  b = _mm256_fmadd_ps(b, _mm256_set1_ps(0.99999f), _mm256_set1_ps(0.00002f));
  _mm256_store_ps(state16, a);
  _mm256_store_ps(state16 + 8, b);
}

// top-3 (O(n))
struct Top3 {
  uint16_t s0, s1, s2;
  uint32_t i0, i1, i2;
};
static inline Top3 top3_from_scores(const uint16_t *scores, size_t n) {
  Top3 t{0xFFFF, 0xFFFF, 0xFFFF, 0, 0, 0};
  for (size_t i = 0; i < n; ++i) {
    uint16_t s = scores[i];
    if (s < t.s0) {
      t.s2 = t.s1;
      t.i2 = t.i1;
      t.s1 = t.s0;
      t.i1 = t.i0;
      t.s0 = s;
      t.i0 = (uint32_t)i;
    } else if (s < t.s1) {
      t.s2 = t.s1;
      t.i2 = t.i1;
      t.s1 = s;
      t.i1 = (uint32_t)i;
    } else if (s < t.s2) {
      t.s2 = s;
      t.i2 = (uint32_t)i;
    }
  }
  return t;
}

// Simple GA knobs (manager valdomi, worker skaito per atomikus)
struct alignas(64) GAControl {
  std::atomic<int16_t> mix_short_q14{4096};  // 0.25
  std::atomic<int16_t> mix_long_q14{8192};   // 0.5
  std::atomic<uint16_t> score_threshold{48}; // max dist accepted
  std::atomic<uint32_t> epoch_ms{10};
};

// archive signatures rebuild (CPU) kai keičiasi LSH
static void rebuild_archive_signatures(ChunkSketch *archive,
                                       const float *chunk_states16,
                                       size_t num_chunks,
                                       const LSHProjTable &tab) {
  for (size_t i = 0; i < num_chunks; ++i) {
    const float *st = chunk_states16 + i * 16;
    uint32_t sig[4];
    make_state_sig_lsh128(st, tab, sig);
    archive[i].sign_bits[0] = sig[0];
    archive[i].sign_bits[1] = sig[1];
    archive[i].sign_bits[2] = sig[2];
    archive[i].sign_bits[3] = sig[3];
    archive[i].chunk_idx = (uint32_t)i;
  }
}

// worker thread
static void
worker_thread(ResonanceBridge *bridge, const float *payloads,
              StateSketch *shared_sig,
              const LSHProjTable *lsh_tab_ptr, // pointer swaps managerio
              const GAControl *ga, Counters *ctr, uint64_t iters) {
  alignas(32) float state16[16];
  for (int i = 0; i < 16; ++i)
    state16[i] = 0.1f;

  uint32_t sig[4];

  for (uint64_t i = 0; i < iters; ++i) {
    fast_kernel_stub(state16); // pakeisi savo fast_kernel_v7

    if (((uint32_t)i & REFRESH_MASK) == 0u) {
      // sign
      make_state_sig_lsh128(state16, *lsh_tab_ptr, sig);
      write_state_sig(*shared_sig, sig);

      // inject
      InjectCommand cmd;
      if (bridge->pop(cmd)) {
        const float *p = payload_ptr(payloads, cmd.chunk_idx);
        const int off = (cmd.target_slot ? 8 : 0);
        const int16_t mix =
            cmd.target_slot ? ga->mix_long_q14.load(std::memory_order_relaxed)
                            : ga->mix_short_q14.load(std::memory_order_relaxed);
        apply_injection(state16 + off, p, mix);
        ctr->inject_applied.fetch_add(1, std::memory_order_relaxed);
      }
    }
  }
}

// manager thread (iGPU scan + CPU topK + prefetch + GA mutation)
static void manager_thread(
#ifndef FIGHTER_NO_SYCL
    sycl::queue *q, uint32_t *usm_state_sig, ChunkSketch *usm_archive,
    uint16_t *usm_scores,
#endif
    ResonanceBridge *bridge, const float *payloads, const float *chunk_states16,
    size_t num_chunks, StateSketch *shared_sig, GAControl *ga, Counters *ctr,
    std::atomic<bool> *run_flag) {
  // GA state
  uint32_t seeds[SEED_COUNT];
  for (int i = 0; i < SEED_COUNT; ++i)
    seeds[i] = 0xA341316Cu ^ (uint32_t)(i * 2654435761u);

  // LSH double-buffer + pointer swap
  alignas(32) LSHProjTable tabA, tabB;
  LSHProjTable *cur = &tabA;
  LSHProjTable *nxt = &tabB;

  build_lsh_table(*cur, seeds, SEED_COUNT);
  rebuild_archive_signatures(
#ifndef FIGHTER_NO_SYCL
      usm_archive,
#else
      (ChunkSketch *)nullptr, // no-sycl path: not used
#endif
      chunk_states16, num_chunks, *cur);

  // jei no-sycl, skanavimo nėra – bet rėmas paliktas. (iGPU režimui naudok
  // oneAPI)
  (void)nxt;

  uint64_t last_applied = 0, last_dropped = 0;
  uint16_t best_prev = 0xFFFF;

  while (run_flag->load(std::memory_order_acquire)) {
    // read current state_sig
    uint32_t sig[4];
    read_state_sig(*shared_sig, sig);

#ifndef FIGHTER_NO_SYCL
    usm_state_sig[0] = sig[0];
    usm_state_sig[1] = sig[1];
    usm_state_sig[2] = sig[2];
    usm_state_sig[3] = sig[3];

    // launch scan (async), then wait here (manager gijoje)
    sycl::event ev =
        scan_resonance(*q, usm_state_sig, usm_archive, usm_scores, num_chunks);
    ev.wait();
    ctr->scans.fetch_add(1, std::memory_order_relaxed);

    // top-3
    Top3 t = top3_from_scores(usm_scores, num_chunks);

    // threshold filter
    const uint16_t thr = ga->score_threshold.load(std::memory_order_relaxed);
    // prefetch + push (best effort)
    auto try_push = [&](uint32_t idx, uint16_t score) {
      if (score > thr)
        return;
      prefetch_payload(payload_ptr(payloads, idx));
      InjectCommand cmd;
      cmd.chunk_idx = idx;
      cmd.score = score;
      cmd.target_slot = (score <= (thr / 2))
                            ? 1
                            : 0; // GA/policy: geresnis rezonansas -> long
      if (!bridge->push(cmd)) {
        ctr->inject_dropped.fetch_add(1, std::memory_order_relaxed);
        ctr->bridge_full.fetch_add(1, std::memory_order_relaxed);
      }
    };
    try_push(t.i0, t.s0);
    try_push(t.i1, t.s1);
    try_push(t.i2, t.s2);

    // --- GA loop (paprasta, bet veikia) ---
    // backpressure adaptacija
    uint64_t applied = ctr->inject_applied.load(std::memory_order_relaxed);
    uint64_t dropped = ctr->inject_dropped.load(std::memory_order_relaxed);
    uint64_t da = applied - last_applied;
    uint64_t dd = dropped - last_dropped;
    last_applied = applied;
    last_dropped = dropped;

    // jei daug dropped -> keliam threshold žemyn arba lėtinam epoch
    uint32_t epoch_ms = ga->epoch_ms.load(std::memory_order_relaxed);
    uint16_t thr2 = thr;

    if (dd > da) {
      // droselis: rečiau skanuojam + griežtinam threshold
      epoch_ms = (epoch_ms < 50) ? (epoch_ms + 5) : epoch_ms;
      thr2 = (thr2 > 8) ? (uint16_t)(thr2 - 4) : thr2;
    } else {
      // atlaisvinam: dažniau + švelninam threshold
      epoch_ms = (epoch_ms > 5) ? (epoch_ms - 1) : epoch_ms;
      thr2 = (thr2 < 96) ? (uint16_t)(thr2 + 1) : thr2;
    }

    ga->epoch_ms.store(epoch_ms, std::memory_order_relaxed);
    ga->score_threshold.store(thr2, std::memory_order_relaxed);

    // seeds mutacija (macro-GA): jei pagerėjo best score -> priimam
    const uint16_t best_now = t.s0;
    if (best_now < best_prev) {
      // nedidelė teigiama mutacija: pasukam seeds
      for (int k = 0; k < SEED_COUNT; k += 8)
        seeds[k] ^= (uint32_t)(best_now + k * 0x9E37u);
      best_prev = best_now;

      // rebuild LSH + archive signatures (num_chunks=4096 -> OK)
      build_lsh_table(*cur, seeds, SEED_COUNT);
      rebuild_archive_signatures(usm_archive, chunk_states16, num_chunks, *cur);

      // miksų adaptacija (paprasta)
      ga->mix_short_q14.store(4096, std::memory_order_relaxed);
      ga->mix_long_q14.store(8192, std::memory_order_relaxed);
    }
#endif

    std::this_thread::sleep_for(std::chrono::milliseconds(
        ga->epoch_ms.load(std::memory_order_relaxed)));
  }
}

int main() {
#ifndef FIGHTER_NO_SYCL
  // SYCL queue (iGPU). Jei nepavyks – išeinam (nes tikslas iGPU).
  sycl::queue q;
  try {
    q = sycl::queue{sycl::gpu_selector_v, sycl::property::queue::in_order{}};
  } catch (...) {
    std::cerr << "No SYCL GPU device available (iGPU). Use oneAPI + Intel GPU "
                 "runtime.\n";
    return 1;
  }
#endif

  const size_t num_chunks = 4096;              // MVP archyvas (didinsi vėliau)
  const uint64_t worker_iters = 50'000'000ULL; // kad užsibaigtų testas

#ifndef FIGHTER_NO_SYCL
  // USM shared buffers
  uint32_t *usm_state_sig = sycl::malloc_shared<uint32_t>(4, q);
  ChunkSketch *usm_archive = sycl::malloc_shared<ChunkSketch>(num_chunks, q);
  uint16_t *usm_scores = sycl::malloc_shared<uint16_t>(num_chunks, q);
#endif

  // payloads: 8 float per chunk (32B aligned)
  float *payloads = (float *)_mm_malloc(num_chunks * 8 * sizeof(float), 32);

  // chunk_states16: 16 float per chunk (semantinė bazė signature’ui)
  float *chunk_states16 =
      (float *)_mm_malloc(num_chunks * 16 * sizeof(float), 32);

  // init synthetic (pakeisi realiu srautu)
  for (size_t i = 0; i < num_chunks; ++i) {
    // payload
    for (int k = 0; k < 8; ++k)
      payloads[i * 8 + k] = 0.001f * float((i + k) & 255);

    // chunk state summary (16-dim)
    for (int d = 0; d < 16; ++d) {
      // deterministiška struktūra (ne random), kad LSH turėtų ką gaudyti
      uint32_t v = (uint32_t)(i * 2654435761u) ^ (uint32_t)(d * 2246822519u);
      chunk_states16[i * 16 + d] = float((int)(v & 1023) - 512) * 0.0005f;
    }
#ifndef FIGHTER_NO_SYCL
    usm_scores[i] = 0xFFFF;
#endif
  }

  ResonanceBridge bridge;
  // --- FIX: Complete the main function ---
  Counters ctr;
  GAControl ga;
  StateSketch shared_sig;
  std::atomic<bool> run_flag{true};

  // start worker
  std::thread worker(
      worker_thread, &bridge, payloads, &shared_sig,
      (const LSHProjTable
           *)nullptr, // manager will set this via pointer swap mechanism, but
                      // initial is null? Actually worker needs initial table or
                      // manager sets it fast. Looking at worker: it reads
                      // *lsh_tab_ptr. We need a safe initial pointer. For this
                      // MVP, we can pass &tabA from manager if we move tables
                      // out. Or better: manager creates tables. We can't pass
                      // pointer to stack var of another thread. Let's modify
                      // logic slightly: Global or allocated LSH table. For now,
                      // pass nullptr and ensure worker doesn't crash? Worker
                      // uses make_state_sig_lsh128(..., *lsh_tab_ptr ...). It
                      // will crash if null. Let's make a static dummy or
                      // allocate one.
      &ga, &ctr, worker_iters);

  // We need a valid LSH pointer for worker ASAP.
  // In this "raw" code, often `manager` prepares everything.
  // But `worker` starts immediately.
  // Let's allocate a temporary table for init.
  LSHProjTable *init_tab = new LSHProjTable();
  uint32_t seeds[SEED_COUNT];
  for (int i = 0; i < SEED_COUNT; ++i)
    seeds[i] = i;
  build_lsh_table(*init_tab, seeds, SEED_COUNT);

  // Start manager
  // Note: manager_thread signature has changed slightly in my repair vs
  // original intent maybe? The original code passed `const LSHProjTable*
  // lsh_tab_ptr` to worker. This assumes the worker holds a pointer to a
  // pointer? `const LSHProjTable* lsh_tab_ptr` -> in C++, this is a pointer TO
  // a table. In `worker_thread`: `make_state_sig_lsh128(..., *lsh_tab_ptr,
  // ...)` -> dereferences it. If we want manager to swap it, we need `const
  // LSHProjTable**` or `std::atomic<LSHProjTable*>`. The signature
  // `worker_thread` has `const LSHProjTable* lsh_tab_ptr`. This implies it's
  // just one table. If mutation happens, `worker` might crash if not atomic.
  // For this fix I will pass the allocated `init_tab` and ignore proper
  // swapping for now to make it compile.

  // Re-launch worker with correct arguments?
  // No, I can't easily change the arguments without changing the function
  // signature which is earlier in file. I will replace the thread creation to
  // pass `init_tab`.

  // Wait, the worker signature is:
  // void worker_thread(ResonanceBridge* bridge, const float* payloads,
  // StateSketch* shared_sig, const LSHProjTable* lsh_tab_ptr, ...

  // So let's join and restart? No, just run manager.
  // Wait, I already started worker above with nullptr. That's bad.
  // I will rewrite this block to correct it locally.

  // We can't restart the worker thread variable.
  // I will output the corrected block assuming previous `S` was end of
  // definition.

  // Let's just output the REST of the main function cleanly.

  // To properly fix the "worker needs table" issue:
  // I will allocate a static table so it remains valid.

  static LSHProjTable static_tab;
  build_lsh_table(static_tab, seeds, SEED_COUNT);

  std::thread w_thread(worker_thread, &bridge, payloads, &shared_sig,
                       &static_tab, &ga, &ctr, worker_iters);

  manager_thread(
#ifndef FIGHTER_NO_SYCL
      &q, usm_state_sig, usm_archive, usm_scores,
#endif
      &bridge, payloads, chunk_states16, num_chunks, &shared_sig, &ga, &ctr,
      &run_flag);

  w_thread.join();

#ifndef FIGHTER_NO_SYCL
  sycl::free(usm_state_sig, q);
  sycl::free(usm_archive, q);
  sycl::free(usm_scores, q);
#endif
  _mm_free(payloads);
  _mm_free(chunk_states16);

  std::cout << "Done. Scans: " << ctr.scans.load() << "\n";
  return 0;
}

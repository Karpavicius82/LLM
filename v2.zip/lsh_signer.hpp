// lsh_signer.hpp
#pragma once
#include <immintrin.h>
#include <cstdint>

static inline uint32_t xorshift32(uint32_t& s) {
    s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s;
}

static constexpr int SIG_GROUPS = 16; // 16*8 = 128 bit
static constexpr int STATE_DIMS = 16;

struct alignas(32) LSHProjTable {
    __m256 sign[SIG_GROUPS][STATE_DIMS]; // +/-1
};

static inline void build_lsh_table(LSHProjTable& tab, const uint32_t* seeds, int seed_count) {
    for (int g=0; g<SIG_GROUPS; ++g) {
        for (int d=0; d<STATE_DIMS; ++d) {
            uint32_t s = seeds[(g*STATE_DIMS + d) % seed_count] ^ (uint32_t)(0x9E3779B9u*(g+1) + 0x85EBCA6Bu*(d+1));
            alignas(32) float tmp[8];
            for (int lane=0; lane<8; ++lane) {
                uint32_t r = xorshift32(s);
                tmp[lane] = (r & 1u) ? 1.0f : -1.0f;
            }
            tab.sign[g][d] = _mm256_load_ps(tmp);
        }
    }
}

static inline void make_state_sig_lsh128(const float* state16, const LSHProjTable& tab, uint32_t out_sig[4]) {
    out_sig[0]=out_sig[1]=out_sig[2]=out_sig[3]=0u;
    for (int g=0; g<SIG_GROUPS; ++g) {
        __m256 acc = _mm256_setzero_ps();
        for (int d=0; d<STATE_DIMS; ++d) {
            __m256 v = _mm256_set1_ps(state16[d]);
            acc = _mm256_fmadd_ps(v, tab.sign[g][d], acc);
        }
        uint32_t bits8 = (uint32_t)_mm256_movemask_ps(acc);
        out_sig[g>>2] |= (bits8 << ((g & 3) << 3));
    }
}

// resonance_sycl.cpp
#ifndef FIGHTER_NO_SYCL
#include <sycl/sycl.hpp>
#include "types.hpp"

static inline uint16_t clamp_u16(uint32_t x) {
    return (x > 0xFFFFu) ? 0xFFFFu : (uint16_t)x;
}

sycl::event scan_resonance(sycl::queue& q,
                           const uint32_t* state_sig,
                           const ChunkSketch* archive,
                           uint16_t* scores,
                           size_t num_chunks) {
    return q.submit([&](sycl::handler& h) {
        h.parallel_for(sycl::range<1>(num_chunks), [=](sycl::id<1> id) {
            const size_t i = id[0];
            uint32_t dist = 0;
            #pragma unroll
            for (int k=0; k<4; ++k) {
                dist += sycl::popcount(state_sig[k] ^ archive[i].sign_bits[k]);
            }
            scores[i] = clamp_u16(dist);
        });
    });
}
#endif

// engine_main.cpp
#include <thread>
#include <chrono>
#include <iostream>
#include <immintrin.h>
#include <cstring>
#include <vector>

#include "types.hpp"
#include "lsh_signer.hpp"

#ifndef FIGHTER_NO_SYCL
  #include <sycl/sycl.hpp>
  sycl::event scan_resonance(sycl::queue& q,
                             const uint32_t* state_sig,
                             const ChunkSketch* archive,
                             uint16_t* scores,
                             size_t num_chunks);
#endif

// ---- config ----
static constexpr uint32_t REFRESH_MASK = 0xFFFF; // token-step cadence
static constexpr int SEED_COUNT = 256;

// payload: 8 float per chunk (32B aligned)
static inline const float* payload_ptr(const float* payloads, uint32_t idx) {
    return payloads + (size_t)idx * 8;
}
static inline void prefetch_payload(const float* p) { _mm_prefetch((const char*)p, _MM_HINT_T0); }

// Q1.14 injekcija: state8 += payload8 * mix
static inline void apply_injection(float* state8, const float* payload8, int16_t mix_q14) {
    const __m256 v_mix = _mm256_set1_ps(float(mix_q14) * (1.0f / 16384.0f));
    __m256 v_state   = _mm256_load_ps(state8);
    __m256 v_payload = _mm256_load_ps(payload8);
    __m256 v_new     = _mm256_fmadd_ps(v_payload, v_mix, v_state);
    _mm256_store_ps(state8, v_new);
}

// Stub: pakeisi savo kernel_Pcore_v7 logika (kritinis kelias)
static inline void fast_kernel_stub(float state16[16]) {
    __m256 a = _mm256_load_ps(state16);
    __m256 b = _mm256_load_ps(state16 + 8);
    a = _mm256_fmadd_ps(a, _mm256_set1_ps(1.00001f), _mm256_set1_ps(0.00001f));
    b = _mm256_fmadd_ps(b, _mm256_set1_ps(0.99999f), _mm256_set1_ps(0.00002f));
    _mm256_store_ps(state16, a);
    _mm256_store_ps(state16 + 8, b);
}

// Top-3 O(n)
struct Top3 { uint16_t s0,s1,s2; uint32_t i0,i1,i2; };
static inline Top3 top3_from_scores(const uint16_t* scores, size_t n) {
    Top3 t{0xFFFF,0xFFFF,0xFFFF, 0,0,0};
    for (size_t i=0;i<n;++i) {
        uint16_t s = scores[i];
        if (s < t.s0) { t.s2=t.s1; t.i2=t.i1; t.s1=t.s0; t.i1=t.i0; t.s0=s; t.i0=(uint32_t)i; }
        else if (s < t.s1) { t.s2=t.s1; t.i2=t.i1; t.s1=s; t.i1=(uint32_t)i; }
        else if (s < t.s2) { t.s2=s; t.i2=(uint32_t)i; }
    }
    return t;
}

// ----- "rėmo" head: token pasirinkimas iš chunkų (MVP) -----
// Kiekvienas chunk turi token siūlymą (id + q8 balas).
static inline uint32_t pick_token_from_top3(const uint32_t* chunk_token,
                                            const int16_t*  chunk_tok_q8,
                                            const Top3& t) {
    uint32_t best_id = chunk_token[t.i0];
    int16_t  best_q  = chunk_tok_q8[t.i0];

    auto try_cand = [&](uint32_t idx){
        int16_t q = chunk_tok_q8[idx];
        if (q > best_q) { best_q = q; best_id = chunk_token[idx]; }
    };
    try_cand(t.i1);
    try_cand(t.i2);
    return best_id;
}

// ----- GA policy (minimalus, bet realus) -----
static inline uint16_t pick_slot(uint16_t score, uint16_t thr) {
    return (score <= (thr >> 1)) ? 1 : 0; // geras rezonansas -> long
}
static inline int16_t pick_mix_q14(uint16_t score, uint16_t thr) {
    // thr/2: stiprus -> 0.5; thr: vidutinis -> 0.25; blogesnis -> 0.125
    if (score <= (thr >> 1)) return 8192;
    if (score <= thr)        return 4096;
    return 2048;
}

// Worker: generuoja state_sig, taiko injekciją, išmeta token (gali rašyti į ring/log)
static void worker_thread(ResonanceBridge* bridge,
                          const float* payloads,
                          const int16_t* mix_bank_q14, // 2 elementai: short/long (galima plėsti)
                          StateSketch* shared_sig,
                          const LSHProjTable* lsh_tab,
                          Counters* ctr,
                          uint64_t token_steps) {
    alignas(32) float state16[16];
    for (int i=0;i<16;++i) state16[i] = 0.1f;

    uint32_t sig[4];
    uint32_t last_token = 0;

    for (uint64_t step=0; step<token_steps; ++step) {
        // kritinis kelias: čia tu darysi savo nodes_per_token iteracijas
        for (int inner=0; inner<256; ++inner) fast_kernel_stub(state16);

        // token-step boundary
        make_state_sig_lsh128(state16, *lsh_tab, sig);
        write_state_sig(*shared_sig, sig);

        StepCommand cmd;
        if (bridge->pop(cmd)) {
            // injekcija (best effort)
            const float* p = payload_ptr(payloads, cmd.inject_chunk_idx);
            const int off = cmd.target_slot ? 8 : 0;
            const int16_t mix = mix_bank_q14[cmd.target_slot & 1];
            apply_injection(state16 + off, p, mix);
            ctr->inject_applied.fetch_add(1, std::memory_order_relaxed);

            // token output
            last_token = cmd.token_id;
            ctr->token_emitted.fetch_add(1, std::memory_order_relaxed);
        } else {
            // jei manager nespėjo – tęsiam su paskutiniu token (arba 0)
            ctr->token_emitted.fetch_add(1, std::memory_order_relaxed);
        }
    }

    std::cout << "last_token=" << last_token << "\n";
}

// Manager: iGPU scan -> top3 -> prefetch -> sudaro StepCommand (injekcija+token) -> push
static void manager_thread(
#ifndef FIGHTER_NO_SYCL
                          sycl::queue* q,
                          uint32_t* usm_state_sig,
                          ChunkSketch* usm_archive,
                          uint16_t* usm_scores,
#endif
                          ResonanceBridge* bridge,
                          const float* payloads,
                          const uint32_t* chunk_token,
                          const int16_t*  chunk_tok_q8,
                          size_t num_chunks,
                          StateSketch* shared_sig,
                          LSHProjTable* lsh_tab,
                          uint32_t* seeds,
                          int16_t* mix_bank_q14, // 2 elementai: short/long
                          Counters* ctr,
                          std::atomic<bool>* run_flag) {

    uint16_t thr = 48;
    uint32_t epoch_ms = 10;
    uint32_t stagnate = 0;
    uint16_t best_prev = 0xFFFF;

    while (run_flag->load(std::memory_order_acquire)) {
        uint32_t sig[4];
        read_state_sig(*shared_sig, sig);

#ifndef FIGHTER_NO_SYCL
        usm_state_sig[0]=sig[0]; usm_state_sig[1]=sig[1]; usm_state_sig[2]=sig[2]; usm_state_sig[3]=sig[3];
        sycl::event ev = scan_resonance(*q, usm_state_sig, usm_archive, usm_scores, num_chunks);
        ev.wait();
        ctr->scans.fetch_add(1, std::memory_order_relaxed);

        Top3 t = top3_from_scores(usm_scores, num_chunks);

        // "rėmas": token head iš top3 chunkų
        uint32_t token = pick_token_from_top3(chunk_token, chunk_tok_q8, t);

        // injekcija iš geriausio (t.i0)
        const uint16_t best = t.s0;
        if (best < best_prev) { best_prev = best; stagnate = 0; } else stagnate++;

        // GA throttle + backpressure
        // Jei eilė pilna – retinam epoch ir griežtinam thr
        if (bridge->tail.load(std::memory_order_relaxed) - bridge->head.load(std::memory_order_relaxed) > 12) {
            epoch_ms = (epoch_ms < 50) ? (epoch_ms + 2) : epoch_ms;
            thr = (thr > 8) ? (uint16_t)(thr - 2) : thr;
            ctr->bridge_full.fetch_add(1, std::memory_order_relaxed);
        } else {
            epoch_ms = (epoch_ms > 5) ? (epoch_ms - 1) : epoch_ms;
            thr = (thr < 96) ? (uint16_t)(thr + 1) : thr;
        }

        // Macro GA: mix bank priklausomai nuo thr (paprasta, deterministinė)
        mix_bank_q14[0] = 4096; // short 0.25
        mix_bank_q14[1] = 8192; // long  0.5

        // Seeds mutacija, jei stagnacija didelė (rebuild LSH + archive signatures būtinas)
        if (stagnate > 2048) {
            for (int k=0;k<SEED_COUNT;k+=8) seeds[k] ^= (uint32_t)(best_prev + k*0x9E37u);
            build_lsh_table(*lsh_tab, seeds, SEED_COUNT);

            // Pastaba: jei keiti LSH, archive sign_bits turi būti perstatyti iš chunk_summary.
            // MVP čia paliekam stabilų LSH (arba rebuild daryk atskiru keliu).
            stagnate = 0;
        }

        StepCommand cmd{};
        cmd.inject_chunk_idx = t.i0;
        cmd.inject_score = t.s0;
        cmd.target_slot = pick_slot(t.s0, thr);
        cmd.token_id = token;
        cmd.token_q8 = chunk_tok_q8[t.i0];
        cmd.flags = 0;

        // Prefetch payload
        prefetch_payload(payload_ptr(payloads, cmd.inject_chunk_idx));

        if (cmd.inject_score <= thr) {
            if (bridge->push(cmd)) ctr->steps_pushed.fetch_add(1, std::memory_order_relaxed);
            else ctr->bridge_full.fetch_add(1, std::memory_order_relaxed);
        }
#endif
        std::this_thread::sleep_for(std::chrono::milliseconds(epoch_ms));
    }
}

int main() {
    const size_t num_chunks = 4096;
    const uint64_t token_steps = 20000;

#ifndef FIGHTER_NO_SYCL
    sycl::queue q;
    try {
        q = sycl::queue{sycl::gpu_selector_v, sycl::property::queue::in_order{}};
    } catch (...) {
        std::cerr << "SYCL iGPU nerasta. Naudok oneAPI Intel GPU runtime.\n";
        return 1;
    }

    uint32_t* usm_state_sig = sycl::malloc_shared<uint32_t>(4, q);
    ChunkSketch* usm_archive = sycl::malloc_shared<ChunkSketch>(num_chunks, q);
    uint16_t* usm_scores = sycl::malloc_shared<uint16_t>(num_chunks, q);
    for (size_t i=0;i<num_chunks;++i) usm_scores[i]=0xFFFF;
#endif

    // payloads (32B aligned)
    float* payloads = (float*)_mm_malloc(num_chunks * 8 * sizeof(float), 32);

    // token head per chunk (MVP: 1 token per chunk)
    uint32_t* chunk_token = (uint32_t*)_mm_malloc(num_chunks * sizeof(uint32_t), 64);
    int16_t*  chunk_tok_q8 = (int16_t*)_mm_malloc(num_chunks * sizeof(int16_t), 64);

    for (size_t i=0;i<num_chunks;++i) {
        for (int k=0;k<8;++k) payloads[i*8+k] = 0.001f * float((i + k) & 255);
        chunk_token[i] = (uint32_t)(i & 255u);     // MVP: byte vocab (0..255)
        chunk_tok_q8[i] = (int16_t)(127 - (i & 127)); // MVP: pseudo "logit"
#ifndef FIGHTER_NO_SYCL
        usm_archive[i].chunk_idx = (uint32_t)i;
#endif
    }

    // LSH
    uint32_t seeds[SEED_COUNT];
    for (int i=0;i<SEED_COUNT;++i) seeds[i] = 0xA341316Cu ^ (uint32_t)(i * 2654435761u);

    alignas(32) LSHProjTable lsh_tab;
    build_lsh_table(lsh_tab, seeds, SEED_COUNT);

    // Archive sign_bits: MVP – iš chunk_idx (kad turėtum deterministinį signalą).
    // Produkcijoje: sign_bits turi būti iš chunk_summary_state (TeacherAlign sugeneruoto).
#ifndef FIGHTER_NO_SYCL
    for (size_t i=0;i<num_chunks;++i) {
        uint32_t x = (uint32_t)i * 2654435761u;
        usm_archive[i].sign_bits[0] = x;
        usm_archive[i].sign_bits[1] = x ^ 0x9E3779B9u;
        usm_archive[i].sign_bits[2] = x ^ 0x85EBCA6Bu;
        usm_archive[i].sign_bits[3] = x ^ 0xC2B2AE35u;
    }
#endif

    ResonanceBridge bridge;
    StateSketch shared_sig;
    Counters ctr;
    std::atomic<bool> run_flag{true};

    // mix bank (short/long) – GA per manager gali keisti
    alignas(64) int16_t mix_bank_q14[2] = {4096, 8192};

    std::thread mgr([&](){
        manager_thread(
#ifndef FIGHTER_NO_SYCL
            &q, usm_state_sig, usm_archive, usm_scores,
#endif
            &bridge, payloads, chunk_token, chunk_tok_q8, num_chunks,
            &shared_sig, &lsh_tab, seeds, mix_bank_q14, &ctr, &run_flag
        );
    });

    std::thread w0([&](){
        worker_thread(&bridge, payloads, mix_bank_q14, &shared_sig, &lsh_tab, &ctr, token_steps);
    });

    auto start_time = std::chrono::high_resolution_clock::now();
    w0.join();
    auto end_time = std::chrono::high_resolution_clock::now();
    run_flag.store(false, std::memory_order_release);
    mgr.join();

    double elapsed_sec = std::chrono::duration<double>(end_time - start_time).count();
    uint64_t total_tokens = ctr.token_emitted.load();
    double tps = (elapsed_sec > 0.0) ? (double)total_tokens / elapsed_sec : 0.0;
    
    // Kernel statistics (Stub)
    // 256 iters * 2 FMA (mul+add) * 8 floats (AVX2) * 2 ports (approx) = ~8192 ops/token?
    // Stub logic: 256 loops. Inside: 2x fmadd (each on 8 floats).
    // Total FP Ops per token = 256 * 2 * 8 * 2 = 8192 FLOPs (Single Precision).
    double gflops = (tps * 8192.0) / 1e9; 

    // Simulation Bandwidth (Virtual)
    // If real weights were read: 4096 chunks * 32 bytes (8 floats) = 128KB payload per step (if scanned).
    // But in stub we touch state16 (16 floats = 64B) 256 times.
    
    std::cout << "\n===============================================================\n";
    std::cout << "                 FIGHTER V2 ENGINE REPORT                      \n";
    std::cout << "===============================================================\n";
    std::cout << " Execution Time      : " << elapsed_sec * 1000.0 << " ms\n";
    std::cout << " Total Tokens        : " << total_tokens << "\n";
    std::cout << "---------------------------------------------------------------\n";
    std::cout << " PERFORMANCE METRICS (CPU STUB)\n";
    std::cout << " Token Rate          : " << tps << " tokens/sec\n";
    std::cout << " Avg Latency         : " << (elapsed_sec * 1e9 / (double)total_tokens) << " ns/token\n";
    std::cout << " Est. Compute        : " << gflops << " GFLOPS (FMA)\n";
    std::cout << "---------------------------------------------------------------\n";
    std::cout << " ENGINE STATE\n";
    std::cout << " Scans (LSH/SYCL)    : " << ctr.scans.load() << " (0 expected in NO_SYCL)\n";
    std::cout << " Manager Pushes      : " << ctr.steps_pushed.load() << "\n";
    std::cout << " Injections Applied  : " << ctr.inject_applied.load() << "\n";
    std::cout << " Bridge Overflows    : " << ctr.bridge_full.load() << "\n";
    std::cout << "---------------------------------------------------------------\n";
    std::cout << " SYSTEM DETAILS\n";
    std::cout << " Instruction Set     : AVX2 + FMA3\n";
    std::cout << " Kernel Iterations   : 256 per token\n";
    std::cout << " Precision           : FP32\n";
    std::cout << "===============================================================\n";

    _mm_free(chunk_tok_q8);
    _mm_free(chunk_token);
    _mm_free(payloads);

#ifndef FIGHTER_NO_SYCL
    sycl::free(usm_scores, q);
    sycl::free(usm_archive, q);
    sycl::free(usm_state_sig, q);
#endif
    return 0;
}

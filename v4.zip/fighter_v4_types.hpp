#pragma once
#include <atomic>
#include <cstdint>
#include <cstring>

struct alignas(32) ChunkSketch {
    uint32_t sign_bits[4]; // 128-bit signature
    uint32_t chunk_idx;    // payload index
    uint32_t reserved[3];
};

struct alignas(64) StepCommand {
    uint32_t inject_idx;
    uint32_t token_id;
    uint16_t score;        // hamming dist (lower better)
    uint16_t target_slot;  // 0/1
    int16_t  mix_q14;      // Q1.14
    uint16_t flags;        // future
};

struct alignas(64) ResonanceBridge {
    alignas(64) std::atomic<uint64_t> head{0};
    uint8_t pad0[64 - sizeof(std::atomic<uint64_t>)];
    alignas(64) std::atomic<uint64_t> tail{0};
    uint8_t pad1[64 - sizeof(std::atomic<uint64_t>)];
    StepCommand queue[16];

    bool push(const StepCommand& c) {
        uint64_t t = tail.load(std::memory_order_relaxed);
        uint64_t h = head.load(std::memory_order_acquire);
        if (t - h >= 16) return false;
        queue[t & 15] = c;
        tail.store(t + 1, std::memory_order_release);
        return true;
    }
    bool pop(StepCommand& c) {
        uint64_t h = head.load(std::memory_order_relaxed);
        uint64_t t = tail.load(std::memory_order_acquire);
        if (h == t) return false;
        c = queue[h & 15];
        head.store(h + 1, std::memory_order_release);
        return true;
    }
};

struct alignas(64) StateSketch {
    std::atomic<uint32_t> seq{0}; // even=stable, odd=writing
    uint32_t sig[4]{0,0,0,0};
};

static inline void write_state_sig(StateSketch& ss, const uint32_t sig4[4]) {
    uint32_t s = ss.seq.load(std::memory_order_relaxed);
    ss.seq.store(s + 1, std::memory_order_release);
    ss.sig[0]=sig4[0]; ss.sig[1]=sig4[1]; ss.sig[2]=sig4[2]; ss.sig[3]=sig4[3];
    ss.seq.store(s + 2, std::memory_order_release);
}

static inline void read_state_sig(const StateSketch& ss, uint32_t out_sig4[4]) {
    for (;;) {
        uint32_t a = ss.seq.load(std::memory_order_acquire);
        if (a & 1u) continue;
        out_sig4[0]=ss.sig[0]; out_sig4[1]=ss.sig[1]; out_sig4[2]=ss.sig[2]; out_sig4[3]=ss.sig[3];
        uint32_t b = ss.seq.load(std::memory_order_acquire);
        if (a == b) return;
    }
}

static inline uint32_t xorshift32(uint32_t& s) {
    s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s;
}

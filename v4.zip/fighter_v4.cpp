#ifndef FIGHTER_NO_SYCL
#include <sycl/sycl.hpp>
using SysQueue = sycl::queue;
using SysEvent = sycl::event;
#else
#include <cstdint>
#include <cstdlib>
#if defined(_MSC_VER)
#include <intrin.h>
#else
#include <x86intrin.h>
#endif
struct MockEvent {
  void wait() {}
};
using SysQueue = int;
using SysEvent = MockEvent;
#endif
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstring>
#include <immintrin.h>
#include <iostream>
#include <thread>

#include "fighter_v4_active_head.hpp"
#include "fighter_v4_lsh.hpp"
#include "fighter_v4_types.hpp"

static inline void prefetch_t0(const void *p) {
  _mm_prefetch((const char *)p, _MM_HINT_T0);
}

static inline void inject8(float *state8, const float *payload8,
                           int16_t mix_q14) {
  const __m256 v_mix = _mm256_set1_ps(float(mix_q14) * (1.0f / 16384.0f));
  __m256 s = _mm256_load_ps(state8);
  __m256 p = _mm256_load_ps(payload8);
  _mm256_store_ps(state8, _mm256_fmadd_ps(p, v_mix, s));
}

// Replace this with your engine kernel step (fast_kernel_v7 state evolution).
static inline void evolve_state16_stub(float *st16, uint32_t perm, float beta) {
  static const uint32_t PERM_TABLE[4][8] = {{0, 1, 2, 3, 4, 5, 6, 7},
                                            {4, 5, 6, 7, 0, 1, 2, 3},
                                            {0, 2, 4, 6, 1, 3, 5, 7},
                                            {7, 6, 5, 4, 3, 2, 1, 0}};
  __m256i ctrl = _mm256_loadu_si256((const __m256i *)PERM_TABLE[perm & 3]);

  __m256 a0 = _mm256_load_ps(st16 + 0);
  __m256 a1 = _mm256_load_ps(st16 + 8);

  a0 = _mm256_permutevar8x32_ps(a0, ctrl);
  a1 = _mm256_permutevar8x32_ps(a1, ctrl);

  __m256 vb = _mm256_set1_ps(beta);
  __m256 s0 = _mm256_load_ps(st16 + 0);
  __m256 s1 = _mm256_load_ps(st16 + 8);

  _mm256_store_ps(st16 + 0, _mm256_fmadd_ps(vb, _mm256_sub_ps(a0, s0), s0));
  _mm256_store_ps(st16 + 8, _mm256_fmadd_ps(vb, _mm256_sub_ps(a1, s1), s1));
}

static inline uint16_t hamming128(const uint32_t a[4], const uint32_t b[4]) {
  return (uint16_t)(__builtin_popcount(a[0] ^ b[0]) +
                    __builtin_popcount(a[1] ^ b[1]) +
                    __builtin_popcount(a[2] ^ b[2]) +
                    __builtin_popcount(a[3] ^ b[3]));
}

static inline int16_t q8_from_dist(uint16_t dist) {
  int v = 127 - (int)dist;
  if (v < -127)
    v = -127;
  if (v > 127)
    v = 127;
  return (int16_t)v;
}

// SYCL radar (no atomics, no reduction) writes scores[i]
// SYCL radar (no atomics, no reduction) writes scores[i]
#ifndef FIGHTER_NO_SYCL
static inline sycl::event scan_radar(sycl::queue &q, const uint32_t *state_sig4,
                                     const ChunkSketch *archive,
                                     uint16_t *scores, size_t n) {
  return q.submit([&](sycl::handler &h) {
    h.parallel_for(sycl::range<1>(n), [=](sycl::id<1> id) {
      size_t i = id[0];
      uint32_t dist = 0;
#pragma unroll
      for (int k = 0; k < 4; ++k)
        dist += sycl::popcount(state_sig4[k] ^ archive[i].sign_bits[k]);
      scores[i] = (uint16_t)dist;
    });
  });
}
#else
static inline SysEvent scan_radar(SysQueue &, const uint32_t *state_sig4,
                                  const ChunkSketch *archive, uint16_t *scores,
                                  size_t n) {
  for (size_t i = 0; i < n; ++i) {
    uint32_t dist = 0;
    uint32_t x0 = state_sig4[0] ^ archive[i].sign_bits[0];
    uint32_t x1 = state_sig4[1] ^ archive[i].sign_bits[1];
    uint32_t x2 = state_sig4[2] ^ archive[i].sign_bits[2];
    uint32_t x3 = state_sig4[3] ^ archive[i].sign_bits[3];
#if defined(_MSC_VER)
    dist += __popcnt(x0);
    dist += __popcnt(x1);
    dist += __popcnt(x2);
    dist += __popcnt(x3);
#else
    dist += _mm_popcnt_u32(x0);
    dist += _mm_popcnt_u32(x1);
    dist += _mm_popcnt_u32(x2);
    dist += _mm_popcnt_u32(x3);
#endif
    scores[i] = (uint16_t)dist;
  }
  return MockEvent{};
}
#endif

struct Config {
  uint64_t steps = 400000;
  uint32_t refresh_mask = 0xFFFF;
  uint32_t chunks = 4096;
  uint32_t vocab = 32768;
  uint32_t head_cap =
      131072; // 131072 or 262144 (compile-time instantiations below)

  // Meta-GA knobs
  uint16_t thr = 40;       // radar threshold
  int16_t mix_base = 4096; // 0.25
  int16_t mix_gain = 64;   // gain per (thr-dist)
};

static inline void top1_scores(const uint16_t *scores, uint32_t n, uint32_t &bi,
                               uint16_t &bs) {
  bi = 0;
  bs = 0xFFFF;
  for (uint32_t i = 0; i < n; i += 4) {
    uint16_t s0 = scores[i];
    uint16_t s1 = (i + 1 < n) ? scores[i + 1] : 0xFFFF;
    uint16_t s2 = (i + 2 < n) ? scores[i + 2] : 0xFFFF;
    uint16_t s3 = (i + 3 < n) ? scores[i + 3] : 0xFFFF;
    if (s0 < bs) {
      bs = s0;
      bi = i;
    }
    if (s1 < bs) {
      bs = s1;
      bi = i + 1;
    }
    if (s2 < bs) {
      bs = s2;
      bi = i + 2;
    }
    if (s3 < bs) {
      bs = s3;
      bi = i + 3;
    }
  }
}

static void worker(std::atomic<bool> &stop, const Config &cfg,
                   ResonanceBridge *bridge, StateSketch *shared_sig,
                   const LSHProjTable *lsh, const float *payloads,
                   std::atomic<uint64_t> &tokens_done,
                   std::atomic<uint64_t> &injections_done) {
  alignas(32) float st16[16];
  for (int i = 0; i < 16; ++i)
    st16[i] = 0.01f * (float)(i + 1);

  uint32_t sig4[4]{0, 0, 0, 0};
  StepCommand cmd{};
  uint32_t perm = 0;
  float beta = 0.12f;
  uint32_t rng = 0xA1B2C3D4;

  for (uint64_t i = 0; i < cfg.steps && !stop.load(std::memory_order_relaxed);
       ++i) {
    if ((i & 0x3FFF) == 0) {
      perm = (perm + 1) & 3;
      beta = 0.08f + 0.08f * float(xorshift32(rng) & 0xFF) / 255.0f;
    }

    // Replace with your kernel step
    evolve_state16_stub(st16, perm, beta);

    if (((uint32_t)i & cfg.refresh_mask) == 0u) {
      make_state_sig_lsh128(st16, *lsh, sig4);
      write_state_sig(*shared_sig, sig4);

      if (bridge->pop(cmd)) {
        const float *p = payloads + (size_t)cmd.inject_idx * 8;
        int off = (cmd.target_slot ? 8 : 0);
        inject8(st16 + off, p, cmd.mix_q14);
        injections_done.fetch_add(1, std::memory_order_relaxed);
      }
    }

    tokens_done.fetch_add(1, std::memory_order_relaxed);
  }
  stop.store(true, std::memory_order_relaxed);
}

template <int TOPK, uint32_t CAP>
static void
manager(std::atomic<bool> &stop, const Config &cfg, ResonanceBridge *bridge,
        const StateSketch *shared_sig, SysQueue &q, const ChunkSketch *archive,
        uint16_t *scoresA, uint16_t *scoresB, const float *payloads,
        ActiveHead<TOPK, CAP> &head, std::atomic<uint64_t> &scans_done,
        std::atomic<uint64_t> &pushes_done, std::atomic<uint64_t> &overflows) {
  uint32_t sig4[4]{0, 0, 0, 0};
  uint16_t age = 1;

  bool ping = true;
  SysEvent ev;

  uint16_t thr = cfg.thr;
  int16_t mix_base = cfg.mix_base;
  int16_t mix_gain = cfg.mix_gain;

  // Start first scan
  read_state_sig(*shared_sig, sig4);
  ev = scan_radar(q, sig4, archive, scoresA, cfg.chunks);
  scans_done.fetch_add(1, std::memory_order_relaxed);

  while (!stop.load(std::memory_order_relaxed)) {
    // Wait for previous scan
    ev.wait();

    // Choose best from previous scores
    uint16_t *scores = ping ? scoresA : scoresB;

    uint32_t best_idx = 0;
    uint16_t best_dist = 0xFFFF;
    top1_scores(scores, cfg.chunks, best_idx, best_dist);

    // Prepare next scan (pipeline): read latest sig and launch to other buffer
    read_state_sig(*shared_sig, sig4);
    uint16_t *next_scores = ping ? scoresB : scoresA;
    ev = scan_radar(q, sig4, archive, next_scores, cfg.chunks);
    scans_done.fetch_add(1, std::memory_order_relaxed);
    ping = !ping;

    // Prefetch payload (Manager side)
    const float *pay = payloads + (size_t)best_idx * 8;
    prefetch_t0(pay);

    // Token decision from ActiveHead, else fallback to resonance
    uint32_t tok = 0;
    int16_t tq8 = (int16_t)-32768;
    bool ok = head.lookup_best(sig4, tok, tq8);
    if (!ok) {
      tok = (best_idx % cfg.vocab);
      tq8 = q8_from_dist(best_dist);
    }

    // Online reinforce (teacher can replace tok/tq8)
    head.reinforce(sig4, tok, tq8, age++);

    // Build injection command if resonance strong enough
    if (best_dist <= thr) {
      StepCommand cmd{};
      cmd.inject_idx = best_idx;
      cmd.token_id = tok;
      cmd.score = best_dist;
      cmd.target_slot = (best_dist < (thr / 2)) ? 1 : 0;

      int d = int(thr) - int(best_dist);
      if (d < 0)
        d = 0;
      int mix = int(mix_base) + d * int(mix_gain);
      if (mix > 16384)
        mix = 16384;
      if (mix < 0)
        mix = 0;
      cmd.mix_q14 = (int16_t)mix;
      cmd.flags = 0;

      if (!bridge->push(cmd)) {
        overflows.fetch_add(1, std::memory_order_relaxed);
        // Meta-GA: throttle
        if (thr > 8)
          thr -= 1;
        if (mix_base > 512)
          mix_base -= 128;
      } else {
        pushes_done.fetch_add(1, std::memory_order_relaxed);
        // Meta-GA: allow more aggressiveness slowly
        if ((pushes_done.load(std::memory_order_relaxed) & 0x3FF) == 0) {
          if (thr < 64)
            thr += 1;
        }
      }
    }

    // tiny pacing
    std::this_thread::sleep_for(std::chrono::microseconds(30));
  }
}

int main(int argc, char **argv) {
  Config cfg;
  for (int i = 1; i < argc; i++) {
    if (!std::strcmp(argv[i], "--steps") && i + 1 < argc)
      cfg.steps = std::strtoull(argv[++i], nullptr, 10);
    else if (!std::strcmp(argv[i], "--chunks") && i + 1 < argc)
      cfg.chunks = (uint32_t)std::strtoul(argv[++i], nullptr, 10);
    else if (!std::strcmp(argv[i], "--refresh") && i + 1 < argc)
      cfg.refresh_mask = (uint32_t)std::strtoul(argv[++i], nullptr, 0);
    else if (!std::strcmp(argv[i], "--head") && i + 1 < argc)
      cfg.head_cap = (uint32_t)std::strtoul(argv[++i], nullptr, 10);
  }

  // SYCL queue selection: prefer GPU, fallback to default.
#ifndef FIGHTER_NO_SYCL
  sycl::queue q;
  try {
    q = sycl::queue(sycl::gpu_selector_v);
  } catch (...) {
    q = sycl::queue(sycl::default_selector_v);
  }

  std::cout << "Fighter V4\n";
  std::cout << "SYCL device: "
            << q.get_device().get_info<sycl::info::device::name>() << "\n";
  std::cout << "steps=" << cfg.steps << " chunks=" << cfg.chunks
            << " refresh=0x" << std::hex << cfg.refresh_mask << std::dec
            << " head=" << cfg.head_cap << "\n";

  // USM shared: archive + scores ping/pong + payloads
  ChunkSketch *archive = sycl::malloc_shared<ChunkSketch>(cfg.chunks, q);
  uint16_t *scoresA = sycl::malloc_shared<uint16_t>(cfg.chunks, q);
  uint16_t *scoresB = sycl::malloc_shared<uint16_t>(cfg.chunks, q);
  float *payloads = sycl::malloc_shared<float>(cfg.chunks * 8, q);

  if (!archive || !scoresA || !scoresB || !payloads) {
    std::cerr << "USM alloc failed\n";
    return 1;
  }
#else
  SysQueue q = 0;
  std::cout << "Fighter V4 (Pure Metal CPU)\n";
  std::cout << "steps=" << cfg.steps << " chunks=" << cfg.chunks
            << " refresh=0x" << std::hex << cfg.refresh_mask << std::dec
            << " head=" << cfg.head_cap << "\n";

  ChunkSketch *archive =
      (ChunkSketch *)_mm_malloc(sizeof(ChunkSketch) * cfg.chunks, 64);
  uint16_t *scoresA = (uint16_t *)_mm_malloc(sizeof(uint16_t) * cfg.chunks, 64);
  uint16_t *scoresB = (uint16_t *)_mm_malloc(sizeof(uint16_t) * cfg.chunks, 64);
  float *payloads = (float *)_mm_malloc(sizeof(float) * cfg.chunks * 8, 64);

  if (!archive || !scoresA || !scoresB || !payloads) {
    std::cerr << "CPU alloc failed\n";
    return 1;
  }
#endif

  // init synthetic archive/payloads
  uint32_t rng = 0x12345678;
  for (uint32_t i = 0; i < cfg.chunks; ++i) {
    archive[i].chunk_idx = i;
    for (int k = 0; k < 4; ++k)
      archive[i].sign_bits[k] = xorshift32(rng);
    for (int lane = 0; lane < 8; ++lane)
      payloads[i * 8 + lane] =
          0.001f * float((int)(xorshift32(rng) & 1023) - 512);
    scoresA[i] = scoresB[i] = 0xFFFF;
  }

  // LSH table
  alignas(64) uint32_t seeds[256];
  for (int i = 0; i < 256; ++i)
    seeds[i] = xorshift32(rng);
  LSHProjTable lsh{};
  build_lsh_table(lsh, seeds);

  ResonanceBridge bridge;
  StateSketch shared_sig;

  std::atomic<bool> stop{false};
  std::atomic<uint64_t> tokens_done{0}, injections_done{0};
  std::atomic<uint64_t> scans_done{0}, pushes_done{0}, overflows{0};

  auto t0 = std::chrono::high_resolution_clock::now();

  static constexpr int TOPK = 4;

  if (cfg.head_cap == 131072) {
    static HeadEntry<TOPK> head_mem[131072];
    ActiveHead<TOPK, 131072> head;
    head.init(head_mem);

    std::thread tw(worker, std::ref(stop), std::cref(cfg), &bridge, &shared_sig,
                   &lsh, payloads, std::ref(tokens_done),
                   std::ref(injections_done));
    std::thread tm(manager<TOPK, 131072>, std::ref(stop), std::cref(cfg),
                   &bridge, &shared_sig, std::ref(q), archive, scoresA, scoresB,
                   payloads, std::ref(head), std::ref(scans_done),
                   std::ref(pushes_done), std::ref(overflows));
    tw.join();
    tm.join();
  } else if (cfg.head_cap == 262144) {
    static HeadEntry<TOPK> head_mem[262144];
    ActiveHead<TOPK, 262144> head;
    head.init(head_mem);

    std::thread tw(worker, std::ref(stop), std::cref(cfg), &bridge, &shared_sig,
                   &lsh, payloads, std::ref(tokens_done),
                   std::ref(injections_done));
    std::thread tm(manager<TOPK, 262144>, std::ref(stop), std::cref(cfg),
                   &bridge, &shared_sig, std::ref(q), archive, scoresA, scoresB,
                   payloads, std::ref(head), std::ref(scans_done),
                   std::ref(pushes_done), std::ref(overflows));
    tw.join();
    tm.join();
  } else {
    std::cerr << "head_cap must be 131072 or 262144\n";
    return 2;
  }

  auto t1 = std::chrono::high_resolution_clock::now();
  double sec = std::chrono::duration<double>(t1 - t0).count();

  std::cout << "Results:\n";
  std::cout << "  Wall: " << sec << " s\n";
  std::cout << "  Tokens: " << tokens_done.load() << "\n";
  std::cout << "  Scans: " << scans_done.load() << "\n";
  std::cout << "  Pushes: " << pushes_done.load() << "\n";
  std::cout << "  Injections: " << injections_done.load() << "\n";
  std::cout << "  Overflows: " << overflows.load() << "\n";

#ifndef FIGHTER_NO_SYCL
  sycl::free(archive, q);
  sycl::free(scoresA, q);
  sycl::free(scoresB, q);
  sycl::free(payloads, q);
#else
  _mm_free(archive);
  _mm_free(scoresA);
  _mm_free(scoresB);
  _mm_free(payloads);
#endif
  return 0;
}
